# Ukraine OSINT Dashboard: Version Log

Newest version first. Each entry says what the version is, what it added compared with the one before, and its known limits. Versioned filenames are the source of truth. Older versions are kept, never overwritten.

**Current version: v0.8** (`ukraine-osint-dashboard-v0.8.html`)

---

## v0.8 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.8.html` (identical to v0.7; the changes are in the pipeline, in `ukraine-dashboard-repo-v0.8.zip`)
**What it is:** v0.7 with wording cleaned up and the fetcher's own settings.

**Added since v0.7**
- Outside references removed from code comments, config notes, and this log.
- Retries now use 4 tries with growing pauses (4, 8, 16 seconds).
- Seam-cleanup width set to about 1.1 m (0.00001 degrees).

**Tested**
- Offline test with made-up TEST shapes passes (name splitting, three occupied types merging into one `russia` row, other categories, unmapped handling, re-runs).
- NOT tested: the merge and seam-cleanup step (shapely could not be installed here), a live fetch, the GitHub workflow, the dashboard in a browser.

**Known limits:** same as v0.7.

---

## v0.7 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.7.html` (identical to v0.6; the change is in the pipeline)
**What it is:** The DeepState fetcher updated with real type names and the real reply layout.

**Added since v0.6**
- The `russia` category now uses exact DeepState type names: `Occupied`, `Occupied Crimea`, `CADR and CALR`, merged into one shape. Names are read as the English part after `///` (DeepState names look like "Ukrainian /// English").
- Address (`https://deepstatemap.live/api/history/last`) and reply layout (`map` > `features`, each with a `name`) confirmed from public examples of DeepState's data.
- After merging, shapes are grown then shrunk by about 1 m to close hairline seams. Default simplification is finer (about 11 m).
- Failed downloads are retried. An honest identifying User-Agent is sent.
- Both Polygon and MultiPolygon shapes are accepted.

**Known limits**
- The other types DeepState returns (liberated, unclear areas, etc.) are still unknown, so those rules remain guesses. The inspect run will list them.
- If DeepState rejects the honest User-Agent, the run fails with an error. Don't disguise the request; ask DeepState for permission instead.
- Not tested live (see v0.8 for what was and wasn't tested).

---

## v0.6 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.6.html` (also inside `ukraine-dashboard-repo-v0.6.zip` as `index.html`)
**What it is:** First real-data pipeline (DeepStateMap occupation polygons) plus a filterable occupation layer on the map.

**Added since v0.5**
- **Pipeline** (`pipeline/fetch_deepstate.py` + `pipeline/config/deepstate.json`): pulls DeepStateMap, sorts each polygon type into a category using editable rules (ukraine, russia, contested, claims, other, plus `unmapped` so nothing is lost or hidden), merges same-category shapes, simplifies them, and saves `data/YYYY-MM-DD/occupation.geojson`, a run log `meta.json`, `data/index.json` and `data/categories.json`. Non-polygon items (units, arrows) are counted in the log and ignored for now.
- **Inspect mode** (`--inspect`, or the "inspect" choice when running the workflow by hand): prints every polygon type the source returns and the category each would get, so the rules can be written from real names.
- **Daily workflow** (`.github/workflows/daily.yml`): runs every day at 05:17 UTC and can be run by hand; saves new data into the repo.
- **SCHEMA.md**: layout and columns of the central daily data folder, including the planned points (features) and claims columns.
- **Dashboard:** new occupation layer loaded from `data/<date>/occupation.geojson`, with one checkbox per category, popups showing original source type names and area, and a link to DeepStateMap. Polygons sit above GeoTIFF layers and below event markers. If no data exists for the selected day, it says so. It never draws placeholder polygons.

**Tested**
- The fetcher's sorting, category rules, hole-aware area calculation, re-run behavior (no duplicates), meta/index/categories files and inspect mode were tested offline with made-up TEST shapes (`pipeline/tests/run_test.py`, passes).
- NOT tested: the polygon merge and simplify step (shapely could not be installed in the build environment, so the test used the no-merge fallback); a real fetch from DeepStateMap; the workflow on GitHub; the dashboard in a browser.

**Known limits**
- The DeepStateMap address in the config (`https://deepstatemap.live/api/history/last`) is UNVERIFIED. I could confirm that an API exists (a third-party project describes its use as officially authorized) but could not confirm the address, its response format, or its terms.
- Category rules are proposals from DeepState's public legend, not from the real data. Run inspect first and confirm them.
- The calendar still lists the sample days, not the days in `data/index.json`. Occupation data appears only for selected days that have a data folder.
- Terms of use and permission to republish DeepState data are unchecked.

---

## v0.5 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.5.html`
**What it is:** v0.4 with the blocked-tiles cause identified and a warning that actually appears in that case.

**Added since v0.4**
- If the page is opened straight from disk (file://), it no longer requests OSM tiles at all. It shows a plain-language message explaining that OSM blocks pages that send no Referer, and how to fix it (host on GitHub Pages or run a local server). Event markers and GeoTIFF upload still work without the base map.
- Reason for the change: the user's screenshot showed OSM's general "App is not following the tile usage policy" (403) tiles when opening the file in Firefox. Blocked tiles are shown as normal images, so v0.4's tile-error warning would not have fired.

**Known limits**
- Not tested in a browser or against OSM's live servers. The likely cause (no Referer from file://) is consistent with the wiki but not proven until the map loads from a hosted page.

---

## v0.4 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.4.html`
**What it is:** v0.3 with changes aimed at the OSM "blocked tiles" problem.

**Added since v0.3**
- The map's tile layer now sets its Referer policy explicitly (Leaflet `referrerPolicy`), which is the fix OSM's Blocked tiles wiki page gives for the "Referer is required" block.
- A plain-language warning appears above the map if tiles fail to load. It says whether the likely cause is opening the file straight from disk, or a browser privacy setting or extension removing the Referer.

**Known limits**
- Not tested in a browser or against OSM's live servers. The real cause of the block on the user's machine is still unconfirmed. It depends on the message written on the blocked tile and on how the page is opened.

---

## v0.3 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.3.html`
**What it is:** The v0.2 dashboard, now following OpenStreetMap's tile usage policy.

**Added since v0.2**
- Attribution now links to openstreetmap.org/copyright.
- An explicit referrer meta tag, so the browser sends the Referer header OSM requires.
- A "Report a map issue" link below the map, which OSM recommends.
- The tile provider is set in one place (the `BASE` line in the script), so it can be switched without other code changes.

**Known limits**
- Tiles only load when the page is served over http(s), such as GitHub Pages or `python3 -m http.server`. Opening the file by double-click sends no Referer and OSM blocks it.
- Still sample data only. Not tested against real GeoTIFFs or against OSM's live servers.
- Note: v0.2 was edited in place to make v0.3, so v0.2 no longer exists as a separate file.

---

## v0.2 (2026-09-20)
**File:** none (overwritten by v0.3)
**What it is:** The mockup with a real OpenStreetMap base map and GeoTIFF upload.

**Added since v0.1**
- Leaflet map with OpenStreetMap tiles instead of the schematic outline.
- Event markers colored by category, with click-through to claims. Clicking a Features row jumps to the marker.
- GeoTIFF upload (button or drag onto the map). Files are read in the browser and never uploaded. Handles single-band and RGB images in EPSG:4326, EPSG:3857, and UTM, reprojected to line up with the map. Per-layer opacity, Zoom to, and Remove.

**Known limits**
- Rotated images are not supported. Other coordinate systems are rejected with a message. Images are downsampled to about 1,400 px. For 3+ band files, the first three bands are used as RGB.

---

## v0.1 (2026-09-20)
**File:** `ukraine-osint-dashboard-v0.1.html` (also published as a preview: https://claude.ai/artifact/DT9phBySDHu7bAvezic2td)
**What it is:** First clickable mockup with generated sample data.

**Included**
- Three tabs: Map, Features (list of the same events), Posts (non-geo items).
- Archive calendar: days with a snapshot are shaded with an event count. Clicking a day reloads all tabs for that day (sample days Aug 24 to Sep 20, 2026).
- Each event has a claims list (source, side, verification status) and a "Confirmed only" filter.
- Day summary placeholder for the future LLM summary.
- Banner stating all content is sample data. Map is a schematic outline, not a real map.

---

## Decisions so far
- **Hosting/schedule:** GitHub Pages plus a scheduled GitHub Actions job, free. The job writes one `data/YYYY-MM-DD.json` per day plus an index of dates, which the calendar reads.
- **Daily summary (LLM):** Provider-agnostic with a fallback chain: GitHub Models (uses the built-in `GITHUB_TOKEN`), then Gemini free tier, then a plain templated summary with no LLM. Not Grok. Summaries separate claims by side.
- **Duplicates:** Match on shared IDs, then normalize, then space/time scoring. Ambiguous pairs only go to an LLM or embeddings. Lean toward not merging. Contradictory claims about one event are kept as multiple claims on one record, not merged into a single "truth."
- **First source (chosen by user): DeepStateMap**, "occupied" = Occupied + Occupied Crimea + CADR and CALR merged,, occupation polygons. Polygon types are sorted into categories by rules in `pipeline/config/deepstate.json`; contradictory sources are kept as separate rows, never blended. Each source writes its own rows into the shared per-day folder (see SCHEMA.md).
- **Base map:** OSM's own tile server first. OSM's Blocked tiles wiki says the block message printed on the tile identifies the cause. Privacy extensions, antivirus, some Firefox settings, and Tor can strip the Referer. Fallback is CARTO Voyager raster with a free API key (its raster tiles are being retired, so vector tiles may be needed later).

- **Hosting visibility (decided 2026-09-20):** Public GitHub repo with GitHub Pages. The code, workflow file, prompts, and data files are all publicly visible. API keys stay in GitHub Secrets and never go in any file. Considered and set aside: Cloudflare Pages from a private repo (public site, hidden code), a Cloudflare Access login, and local-only use.

## Open items
- Run the workflow once in "inspect" mode and send the output to Claude, to confirm the address works and to write rules for the non-occupied types.
- Check DeepStateMap's terms and ask for permission to republish their polygons if required (their site or Telegram has contact details); put a real contact in the `user_agent` setting.
- Check that the daily commit triggers a GitHub Pages rebuild, and whether daily commits keep the workflow from being disabled after 60 days.
- Repo size: keep only simplified files for each day (raw responses are off by default), since Pages sites are limited in size.
- Decide what "claims" means as a category and which source will feed it.
- Switch the calendar to read `data/index.json`; decide whether a login is needed and for what.
- Confirm the map loads once the page is hosted on GitHub Pages. If tiles are still blocked there, note the exact message on the tile.
- Choose the actual data sources.
- Write the fetch/merge script, the GitHub Actions workflow, and switch the page from sample data to `data/` files.
- Test the GeoTIFF upload with a real file.
- Real Posts tab sources, translation, and archiving cited links (Wayback snapshots).
