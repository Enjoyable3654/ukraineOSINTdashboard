#!/usr/bin/env python3
"""
DeepStateMap -> daily, categorized occupation polygons.

  python pipeline/fetch_deepstate.py --inspect      show what the source returns; saves nothing
  python pipeline/fetch_deepstate.py                fetch, categorize, save into data/<today>/
  python pipeline/fetch_deepstate.py --from-file F  use a saved response instead of the network (testing)

Settings live in pipeline/config/deepstate.json. Nothing is dropped silently: polygons that match no
rule are kept as category "unmapped", and non-polygon items are counted in the run log (meta.json).
"""
import argparse, collections, datetime as dt, gzip, json, math, re, sys, time, urllib.request
from pathlib import Path

try:
    from shapely.geometry import shape, mapping
    from shapely.ops import unary_union
    HAVE_SHAPELY = True
except ImportError:  # the script still runs, but polygons are not merged or simplified
    HAVE_SHAPELY = False

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "pipeline" / "config" / "deepstate.json"


def die(msg):
    print("ERROR: " + msg, file=sys.stderr)
    sys.exit(1)


def fetch(url, user_agent, tries=4, wait=4):
    """Download JSON, retrying with growing pauses (4, 8, 16 s). Sends an honest, identifying User-Agent."""
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": user_agent, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            print(f"  attempt {i + 1}/{tries} failed: {e}", file=sys.stderr)
            if i == tries - 1:
                raise
            time.sleep(wait)
            wait *= 2


def find_feature_collection(node):
    """The response may wrap the GeoJSON inside other keys, so search for it."""
    if isinstance(node, dict):
        if node.get("type") == "FeatureCollection" and isinstance(node.get("features"), list):
            return node
        node = list(node.values())
    if isinstance(node, list):
        for v in node:
            found = find_feature_collection(v)
            if found:
                return found
    return None


def label_of(props, cfg):
    """DeepState names look like '<Ukrainian> /// <English>'. Keep the English part (settings: name_separator, name_part)."""
    raw = str(props.get("name") or "").strip()
    sep = cfg.get("name_separator")
    if sep and sep in raw:
        parts = [p.strip() for p in raw.split(sep)]
        i = cfg.get("name_part", 1)
        raw = parts[i] if i < len(parts) else parts[-1]
    return raw or str(props.get("fill") or "(no label)")


def classify(label, props, rules):
    for r in rules:
        if "names" in r and label.lower() not in [n.lower() for n in r["names"]]:
            continue
        if "regex" in r and not re.search(r["regex"], label, re.I):
            continue
        if any(props.get(k) != v for k, v in r.get("props", {}).items()):
            continue
        return r["category"]
    return "unmapped"


def xy(c):
    """Keep only [lon, lat] (drop any height value) and round to ~1 m."""
    if isinstance(c[0], (int, float)):
        return [round(c[0], 5), round(c[1], 5)]
    return [xy(x) for x in c]


def to_polygons(g):
    t = g.get("type")
    if t == "Polygon":
        return [xy(g["coordinates"])]
    if t == "MultiPolygon":
        return [xy(p) for p in g["coordinates"]]
    return []


def ring_area_km2(ring):
    R, total = 6371.0088, 0.0
    for (x1, y1), (x2, y2) in zip(ring, ring[1:]):
        total += math.radians(x2 - x1) * (2 + math.sin(math.radians(y1)) + math.sin(math.radians(y2)))
    return abs(total) * R * R / 2


def polygons_area_km2(polys):
    return sum(ring_area_km2(p[0]) - sum(ring_area_km2(h) for h in p[1:]) for p in polys)


def dissolve(polys, tol, eps):
    """Merge all polygons of one category into one shape. Returns (geometry, note)."""
    if HAVE_SHAPELY:
        merged = unary_union([shape({"type": "Polygon", "coordinates": p}).buffer(0) for p in polys])
        if eps > 0:  # grow then shrink by ~1 m to close hairline seams left by the merge
            merged = merged.buffer(eps, quad_segs=1, join_style="mitre").buffer(-eps, quad_segs=1, join_style="mitre")
        if tol > 0:
            merged = merged.simplify(tol, preserve_topology=True)
        g = mapping(merged)
        return {"type": g["type"], "coordinates": xy(g["coordinates"])}, "merged and simplified"
    return {"type": "MultiPolygon", "coordinates": polys}, "NOT merged or simplified (shapely not installed)"


def print_inspect(payload, fc, cfg):
    print("Top-level keys:", list(payload.keys()) if isinstance(payload, dict) else type(payload).__name__)
    print("Features:", len(fc["features"]))
    groups = collections.defaultdict(lambda: [0, 0.0])
    for f in fc["features"]:
        g, props = f.get("geometry") or {}, f.get("properties") or {}
        key = (label_of(props, cfg), props.get("fill"), props.get("stroke"), g.get("type"))
        groups[key][0] += 1
        groups[key][1] += polygons_area_km2(to_polygons(g))
    print("\nEach distinct type found (label | fill | stroke | shape): count, approx km2 -> category it would get")
    for (label, fill, stroke, gt), (n, area) in sorted(groups.items(), key=lambda kv: -kv[1][1]):
        cat = classify(label, {"fill": fill, "stroke": stroke}, cfg["rules"]) if gt in ("Polygon", "MultiPolygon") else "(not a polygon, ignored)"
        print(f"  {label} | {fill} | {stroke} | {gt}: {n}, {area:,.0f} -> {cat}")
    sample = next((f.get("properties") for f in fc["features"] if f.get("properties")), None)
    print("\nExample of one feature's raw properties:", json.dumps(sample, ensure_ascii=False)[:600])


def read_json(path, default):
    return json.loads(path.read_text("utf-8")) if path.exists() else default


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), "utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inspect", action="store_true")
    ap.add_argument("--from-file")
    ap.add_argument("--date", help="folder date YYYY-MM-DD (default: today, UTC)")
    ap.add_argument("--data-dir", default=str(ROOT / "data"))
    ap.add_argument("--keep-raw", action="store_true", help="also save the raw response as .json.gz (large)")
    args = ap.parse_args()

    cfg = json.loads(CONFIG.read_text("utf-8"))
    try:
        payload = json.load(open(args.from_file, encoding="utf-8")) if args.from_file else fetch(cfg["endpoint"], cfg["user_agent"])
    except Exception as e:
        die(f"could not get data from {args.from_file or cfg['endpoint']}: {e}")
    fc = find_feature_collection(payload)
    if not fc:
        die("no GeoJSON FeatureCollection found in the response. Run with --inspect and send the output to Claude.")
    if args.inspect:
        return print_inspect(payload, fc, cfg)

    now = dt.datetime.now(dt.timezone.utc)
    day = args.date or now.strftime("%Y-%m-%d")
    snap = payload.get("datetime") if isinstance(payload, dict) and isinstance(payload.get("datetime"), str) else None
    polys, labels, skipped, n_feat = collections.defaultdict(list), collections.defaultdict(set), collections.Counter(), collections.Counter()
    for f in fc["features"]:
        g, props = f.get("geometry") or {}, f.get("properties") or {}
        parts = to_polygons(g)
        if not parts:
            skipped[str(g.get("type"))] += 1
            continue
        label = label_of(props, cfg)
        cat = classify(label, props, cfg["rules"])
        polys[cat].extend(parts)
        labels[cat].add(label)
        n_feat[cat] += 1
    if not polys:
        die("the response contained no polygons; nothing saved (existing data left untouched).")

    features, by_cat, note = [], {}, ""
    for cat, plist in polys.items():
        geom, note = dissolve(plist, cfg["simplify_degrees"], cfg.get("cleanup_buffer_degrees", 0))
        area = polygons_area_km2(geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]])
        by_cat[cat] = {"source_polygons": n_feat[cat], "area_km2_approx": round(area)}
        features.append({"type": "Feature", "geometry": geom, "properties": {
            "source": cfg["source_id"], "source_name": cfg["source_name"], "source_url": cfg["source_url"],
            "category": cat, "category_label": cfg["categories"].get(cat, {}).get("label", cat),
            "snapshot_time": snap, "fetched_at_utc": now.isoformat(timespec="seconds"),
            "source_labels": sorted(labels[cat]), "source_polygons": n_feat[cat],
            "area_km2_approx": round(area), "processing": note}})

    data = Path(args.data_dir)
    occ_path = data / day / "occupation.geojson"
    kept = [f for f in read_json(occ_path, {"features": []})["features"] if f["properties"].get("source") != cfg["source_id"]]
    write_json(occ_path, {"type": "FeatureCollection", "features": kept + features})

    meta_path = data / day / "meta.json"
    meta = read_json(meta_path, {"date": day, "sources": {}})
    meta["sources"][cfg["source_id"]] = {
        "status": "ok", "fetched_at_utc": now.isoformat(timespec="seconds"), "snapshot_time": snap,
        "endpoint": args.from_file or cfg["endpoint"], "by_category": by_cat,
        "unmapped_labels": sorted(labels.get("unmapped", [])), "skipped_non_polygon": dict(skipped), "processing": note}
    write_json(meta_path, meta)
    if args.keep_raw:
        with gzip.open(data / day / f"{cfg['source_id']}_raw.json.gz", "wt", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False)

    write_json(data / "categories.json", {"categories": cfg["categories"]})
    dates = sorted(p.parent.name for p in data.glob("*/occupation.geojson"))
    write_json(data / "index.json", {"dates": dates, "updated_utc": now.isoformat(timespec="seconds")})

    print(f"Saved {occ_path}  ({note})")
    for cat, v in by_cat.items():
        print(f"  {cat}: {v['source_polygons']} source polygons, about {v['area_km2_approx']:,} km2")
    if "unmapped" in by_cat:
        print("  WARNING: some types matched no rule:", "; ".join(sorted(labels["unmapped"])))
    if skipped:
        print("  Ignored non-polygon items:", dict(skipped))


if __name__ == "__main__":
    main()
