"""Offline test: python pipeline/tests/run_test.py  (uses only made-up TEST shapes near 0,0)"""
import json, subprocess, sys, tempfile
from pathlib import Path
here = Path(__file__).resolve().parent
script = here.parent / "fetch_deepstate.py"
fix = here / "fixture_deepstate_TEST_ONLY.json"
with tempfile.TemporaryDirectory() as d:
    run = lambda *a: subprocess.run([sys.executable, str(script), "--from-file", str(fix), "--data-dir", d, "--date", "2000-01-01", *a], capture_output=True, text=True)
    r = run(); print(r.stdout, r.stderr); assert r.returncode == 0
    r2 = run(); assert r2.returncode == 0          # running twice must not duplicate features
    occ = json.loads((Path(d) / "2000-01-01" / "occupation.geojson").read_text())
    cats = sorted(f["properties"]["category"] for f in occ["features"])
    assert cats == ["contested", "russia", "ukraine", "unmapped"], cats
    ru = next(f for f in occ["features"] if f["properties"]["category"] == "russia")["properties"]
    assert ru["source_polygons"] == 3 and ru["source_labels"] == ["CADR and CALR", "Occupied", "Occupied Crimea"], ru
    meta = json.loads((Path(d) / "2000-01-01" / "meta.json").read_text())["sources"]["deepstate"]
    assert meta["skipped_non_polygon"] == {"Point": 1, "LineString": 1}, meta
    assert meta["unmapped_labels"] == ["TEST something new"], meta
    assert json.loads((Path(d) / "index.json").read_text())["dates"] == ["2000-01-01"]
    assert "ukraine" in json.loads((Path(d) / "categories.json").read_text())["categories"]
    print("ALL TESTS PASSED")
