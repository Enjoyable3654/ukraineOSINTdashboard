# Central daily data repository: layout and columns

Everything the dashboard shows lives under `data/`, one folder per UTC day. Each source's script writes only its own rows (matched by the `source` column), so re-running a day replaces that source's rows and leaves the others alone.

```
data/
  index.json                 list of dates that have data (the calendar reads this)
  categories.json            occupation categories: id, label, color
  YYYY-MM-DD/
    occupation.geojson       polygons, one row per source and category (built now)
    features.geojson         geolocated events as points (planned)
    posts.json               non-geo items (planned)
    meta.json                run log per source: status, times, counts, unmapped types
```

## occupation.geojson (polygons)
| column | meaning |
|---|---|
| source, source_name, source_url | which source and where to find it |
| category | one of the ids in categories.json (ukraine, russia, contested, claims, other, unmapped) |
| category_label | readable name of the category |
| snapshot_time | time the source says its map was updated (if it says) |
| fetched_at_utc | when our job pulled it |
| source_labels | the original type names from the source that were merged into this category |
| source_polygons | how many source shapes were merged |
| area_km2_approx | rough area in square km (about 0.3% accuracy) |
| processing | whether shapes were merged and simplified |

Categories are kept as separate layers and are never subtracted from each other. Where sources disagree, each source keeps its own row instead of being blended into one "truth".

## features.geojson (points, planned)
`id, source, source_event_id, category, title, description, timestamp_utc, place_name, side, verification_status, claims[], links[], media_links[], first_seen, last_seen, duplicate_group_id`, with the point location as the geometry. `claims[]` holds one entry per report: `{source, side, text, url, archived_url}`. Duplicates are grouped, not merged.
